1. 'Nop.Plugin.Widgets.WinstantPayInvoice' directory contains source code.
2. 'Widgets.WinstantPayInvoice' contains binaries. Just drop it into \Plugins directory on your server.